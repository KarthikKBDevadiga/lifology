const Constants = {
    baseUrl: "http://35.240.234.200:7996",
}

export default Constants;